import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    tip: '页面测试'
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})
