module.exports = {
  outputDir: process.env.outputDir
}
