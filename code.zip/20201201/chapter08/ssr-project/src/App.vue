<template>
  <div id="app">test</div>
</template>

<script>
export default {
  name: 'app'
}
</script>
