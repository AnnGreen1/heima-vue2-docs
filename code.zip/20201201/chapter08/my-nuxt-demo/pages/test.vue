<template>
  <div>
    <div>
      <nuxt-link to="/sub/test">跳转到sub/test</nuxt-link>
    </div>
    <div>test</div>
  </div>
</template>
