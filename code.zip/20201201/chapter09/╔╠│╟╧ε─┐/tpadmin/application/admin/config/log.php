<?php
return [
    // 为避免读者环境没有安装远程调试导致项目速度变慢，将type注释起来
    // 如果安装了远程调试请取消注释即可
    // 'type' => 'socket',
    'host' => '127.0.0.1',
    // 只允许指定的客户端id读取日志
    'allow_client_ids' => ['thinkphp_zfH5NbLn']
];
