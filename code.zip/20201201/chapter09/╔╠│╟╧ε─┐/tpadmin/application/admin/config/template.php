<?php
return [
    'tpl_replace_string'  =>  [
        '__STATIC__' => '/static/admin',
        '__CDN__' => '/static/common',
        '__UPLOAD__' => '/static/uploads'
    ]
];
