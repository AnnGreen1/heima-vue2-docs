<?php
return [
    'auto_timestamp' => 'timestamp',
];
