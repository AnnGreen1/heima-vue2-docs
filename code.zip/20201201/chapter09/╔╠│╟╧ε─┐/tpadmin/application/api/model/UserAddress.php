<?php
namespace app\api\model;

use think\Model;

class UserAddress extends Model
{
}
