<?php
namespace app\api\model;

use think\Model;

class AlbumImage extends Model
{
}
