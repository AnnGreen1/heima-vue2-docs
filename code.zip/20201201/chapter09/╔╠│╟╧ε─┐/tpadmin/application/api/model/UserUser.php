<?php
namespace app\api\model;

use think\Model;

class UserUser extends Model
{
}
