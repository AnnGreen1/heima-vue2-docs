<?php
namespace app\api\model;

use think\Model;

class GoodsGoods extends Model
{
}
